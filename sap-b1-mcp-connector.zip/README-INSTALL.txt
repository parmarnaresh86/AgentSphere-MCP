SAP B1 MCP Connector — Portable Package
========================================

Contents:
  dist/                    Built MCP server (ready to run)
  src/                     TypeScript source (for rebuilding if you change it)
  package.json / lock      Dependency list
  tsconfig.json            Build config
  .env                     SAP B1 credentials (WMS Dev UK / silverdemo)
  install-desktop-mcp.ps1  One-command installer for Claude Desktop
  DESKTOP_MCP_SETUP.md     Full setup/reference doc

SETUP ON A NEW MACHINE
-----------------------
1. Extract this zip anywhere, e.g. C:\sap-b1-mcp\
2. Open a terminal in that folder and install dependencies:
       npm install
3. Make sure Claude Desktop is installed and has been run at least once.
4. Run the installer:
       powershell -ExecutionPolicy Bypass -File .\install-desktop-mcp.ps1
   This registers the connector in Claude Desktop's config automatically,
   using the credentials in .env.
5. Fully quit Claude Desktop (system tray -> Quit) and reopen it.
6. In a new chat, ask something like:
       "Use the SAP B1 MCP tool to get the customer list from WMS Dev UK"
   If it returns real data, you're connected.

NOTES
-----
- .env contains a live SAP password in plain text. Treat this zip like a
  credentials file — don't share it or commit it anywhere public.
- To rebuild the server after changing src/server.ts:
       npm run build
- Full setup notes: see DESKTOP_MCP_SETUP.md
