# mcpsql-connector — Claude Desktop Setup

## What this is

An MCP connector exposing SAP Business One tools (same 60+ tools as the
`sap-b1-wms-dev-uk` connector) for the **NOCPL_LIVE** company, hosted on:

```
DESKTOP-ICFN0OJ  (SQL Server instance: DESKTOP-ICFN0OJ\SQLEXPRESS01)
```

## ⚠️ Known issue — Service Layer login currently fails

As of packaging, `manager` / `Admin@123` **authenticates successfully in the
SAP Business One desktop client** against `NOCPL_LIVE`, but the same
credentials are **rejected by SAP Service Layer (REST API, port 50000)** with:

```
SAP error 206: "Invalid login credential."
```

This was confirmed not to be a credentials or request-format problem — the
exact same JSON body was verified byte-for-byte, and the login was retried
against `localhost`, the machine hostname, and both `/b1s/v1` and `/b1s/v2`
paths, all with identical failures.

**Most likely cause:** Service Layer has its own SLD (System Landscape
Directory) registration, separate from what the desktop client uses. If that
registration doesn't correctly point at `DESKTOP-ICFN0OJ\SQLEXPRESS01`, or if
Service Layer isn't enabled for this specific company, logins fail via the
API while the desktop client works fine.

**Before using this connector**, have whoever administers this SAP B1
install check:
1. Service Layer / SLD configuration (SAP Business One Server Tools) —
   confirm it's registered against `DESKTOP-ICFN0OJ\SQLEXPRESS01`
2. That Service Layer access is enabled for the `NOCPL_LIVE` company
3. Ideally, test a login directly with a Service Layer test tool (e.g.
   Postman) from the SAP server machine itself, to rule out any
   network-path issue

Once Service Layer login is confirmed working (e.g. via a successful
`POST /Login` from any tool), this connector should work immediately — no
code changes needed here, just re-run the installer if the working
`SL_BASE_URL` ends up different from what's in `.env`.

## Network address — read before installing on another machine

`.env` currently points `SL_BASE_URL` at this laptop's LAN IP
(`10.81.234.2`) since SAP is running on it, not on a separate server. If you
install this connector:

- **On this same laptop** → change `SL_BASE_URL` in `.env` to
  `https://localhost:50000/b1s/v1` first (more reliable than an IP that can
  change).
- **On a different machine** → the IP `10.81.234.2` must actually be
  reachable from that machine (same LAN or VPN). If this laptop's IP has
  changed, or you're on a different network segment, update `.env`
  accordingly before running the installer. You'll also need Windows
  Firewall on this laptop to allow inbound TCP 50000 from the other machine.

## Installing

1. Extract this package anywhere, e.g. `C:\mcpsql-connector\`
2. Install dependencies:
   ```
   npm install
   ```
3. Confirm/adjust `SL_BASE_URL` in `.env` per the network note above
4. Run the installer:
   ```
   powershell -ExecutionPolicy Bypass -File .\install-desktop-mcp.ps1
   ```
5. Fully quit Claude Desktop (system tray → Quit) and reopen it
6. Test with: *"Use the mcpsql-connector MCP tool to list customers from
   NOCPL_LIVE"* — if it errors with SAP code 206, the Service Layer issue
   above hasn't been resolved yet.
