mcpsql-connector — Portable Package (NOCPL_LIVE)
====================================================

*** Service Layer login is NOT confirmed working for these credentials yet.
*** See DESKTOP_MCP_SETUP.md before relying on this connector.

Contents:
  dist/                    Built MCP server (ready to run)
  src/                     TypeScript source
  package.json / lock      Dependency list
  tsconfig.json            Build config
  .env                     SAP credentials for NOCPL_LIVE (see notes inside)
  install-desktop-mcp.ps1  One-command installer for Claude Desktop
  DESKTOP_MCP_SETUP.md     Full setup/reference doc + known issue details

QUICK SETUP
-----------
1. Extract this zip, e.g. C:\mcpsql-connector\
2. npm install
3. Check .env — SL_BASE_URL may need adjusting depending on where you're
   installing this (see DESKTOP_MCP_SETUP.md "Network address" section)
4. powershell -ExecutionPolicy Bypass -File .\install-desktop-mcp.ps1
5. Fully quit Claude Desktop (system tray -> Quit) and reopen it
6. Test: "Use the mcpsql-connector MCP tool to list customers from NOCPL_LIVE"

If step 6 returns a SAP error code 206, Service Layer isn't authenticating
these credentials yet — that's a known, unresolved issue on the SAP server
side as of packaging. See DESKTOP_MCP_SETUP.md for what to check.
